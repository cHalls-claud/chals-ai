# ©HALS$ — chals.ai
**AI BLOCKCHAIN • 99 Asmaul Husna — Level 7 [7X]**
$ Putih Mata Uang | © Hitam Crypto | H 99 Asmaul Husna

🌐 **Live:** https://chals.ai  
🔌 **API:** https://api.chals.ai  
🔒 **SSL:** GitHub Pages + Let's Encrypt (Enforce HTTPS ON)

### 🚀 Deployment - GitHub Pages
Repo ini sudah optimized untuk GitHub Pages + Custom Domain.

**DNS Records (di Cloudflare / Dynadot / Namecheap):**
```
Type A    @    185.199.108.153
Type A    @    185.199.109.153
Type A    @    185.199.110.153
Type A    @    185.199.111.153
Type CNAME www  ->  mhmdirsal1810.github.io
```

**Cara Deploy:**
1. Push repo ini ke GitHub `mhmdirsal1810/chals-ai`
2. Settings → Pages → Custom domain: `chals.ai` → Save
3. Tunggu 1-2 menit → centang Enforce HTTPS

### 📁 Struktur
- `index.html` - Landing final premium
- `404.html` - Fallback untuk SPA routing custom domain
- `CNAME` - Custom domain config
- `.nojekyll` - Bypass Jekyll processing

© 2026 HALS$ - All Rights Reserved
